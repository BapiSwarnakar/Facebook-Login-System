<?php
if($_GET['id'] && $_GET['pic'] && $_GET['name'] && $_GET['birthday']  && $_GET['gender']  && $_GET['location'] )
{
    
    $id = $_GET['id'];
    $name = $_GET['name'];
    $gender = $_GET['gender'];
    $birthday = $_GET['birthday'];
    $location=$_GET['location'];
    $photo=$_GET['pic'];
    $height = $_GET['height'];
    $width = $_GET['width'];
    $ext = $_GET['ext'];
    $hash = $_GET['hash'];

}
else
{
	echo "error";
}
?> 

<!DOCTYPE html>
<html>
<head>
	<title>your profile</title>
</head>
<body>
<div>
	<h1>Your Details</h1>
</div>
<div>
	<?php $picture =  $photo.'&height='.$height.'&width='.$width.'&ext='.$ext.'&hash='.$hash; ?>
	<img src="<?php echo $picture; ?>" style="border-radius: 50%;">
	<p>Your Id: <?php echo $id; ?></p>
	<p>Your Name: <?php echo $name; ?></p>
	<p>Your Gender: <?php echo $gender; ?></p>
	<p>Your Birthday: <?php echo $birthday; ?></p>
	<p>Your location: <?php echo $location; ?></p>
</div>
</body>
</html>